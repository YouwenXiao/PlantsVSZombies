package plantvszombies.entity.plants.attackplants;

import plantvszombies.entity.plants.AttackPlants;

public class Peashooter extends AttackPlants {

	
	public Peashooter() {
		super("豌豆射手", 300, 7500, 100, 0, 0, 0, 0, new String[]{"草地","花盆","睡莲"}, 20, "正前方一整行", 1400);
	}



	@Override
	public void attack() {
		
		System.out.printf("【%s】正在攻击\n\n",this.getName());
	}



	@Override
	public String toString() {
		return String.format("%s%s\r\n" + 
				"耐久\r\n" + 
				"临界点\r\n" + 
				"攻击%s\r\n" + 
				"范围%s\r\n" + 
				"攻击间隔\r\n" + 
				"价格\r\n" + 
				"冷却时间\r\n" + 
				"可栽种于可栽种于草地/睡莲/花盆%s\r\n" + 
				"每次攻击射出一发豌豆", 
				this.getClass().getSimpleName(),this.getName(),
				this.getHitPiont(),
				this.getCriticalPiont(),
				this.getAttackPiont(),
				this.getRange(),
				this.getRecharge() / 1000.0,
				this.getCost(),
				this.getCooldownTime() / 1000.0,
				this.getPlaces());
	}
	
	

}