package plantvszombies.entity.plants.attackplants;

import plantvszombies.entity.plants.AttackPlants;

/**
 * 
 *项目名称:Plants vs.Zombies
 *类名称:Chomper
 *
 *类描述:食人花（咀嚼者）
 *
 * @作者  黄天佑
 * @时间 2017年10月30日上午1:20:13
 * @地点   教室
 * @version-1.0.0
 */
public class Chomper  extends AttackPlants{
	public Chomper() {
		super("食人花（咀嚼者）",300,7500,150,0,0,0,0,new String[]{"草地","花盆","睡莲"},1800,"正前方约1.5格",42000);
		
	}

	@Override
	public void attack() {
		
		System.out.printf("【%s】正在攻击%n",this.getName());
	}

	@Override
	public String toString() {
		return String.format("%s%s\r\n"+
                           "耐久:%s\r\n"+
                           "临界点:%s\r\n"+
                           "攻击:%s对巨人40 可秒杀高坚果僵尸\r\n"+
                           "范围:%s\r\n"+
                           "咀嚼时间:%s秒\r\n"+
                           "价格: %s阳光\r\n"+
                           "冷却时间:%s秒\r\n"+
                           "可栽种于可栽种于草地/睡莲/花盆\r\n"+
                           "特性：: 吞下所有自己可以吞下的僵尸",
                           this.getClass().getSimpleName(),this.getName(),
                           this.getHitPiont(),
                           this.getCriticalPiont(),
                           this.getAttackPiont(),
                           this.getRange(),
                           this.getRecharge()/1000,
                           this.getCost(),
                           this.getCooldownTime()/1000.0,
                           this.getPlaces());
	}
	
}

