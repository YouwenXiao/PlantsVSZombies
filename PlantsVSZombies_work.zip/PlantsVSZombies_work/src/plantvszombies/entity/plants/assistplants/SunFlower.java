package plantvszombies.entity.plants.assistplants;

import plantvszombies.entity.plants.AssistPlants;

public class SunFlower extends AssistPlants {

	public SunFlower() {
		super("向日葵", 300, 7500, 50, 0, 0, 0, 0, new String[]{"草地","花盆","睡莲"}, 2400);
	}
	
	@Override
	public void production() {
		System.out.printf("【%s】生产出一个太阳\n\n",this.getName());
	}
	
	public String toString() {
		return String.format("%s%s\r\n" + 
				"耐久\r\n" + 
				"临界点\r\n" +  
				"生产间隔\r\n" + 
				"价格\r\n" + 
				"冷却时间\r\n" + 
				"可栽种于可栽种于草地/睡莲/花盆%s\r\n" + 
				"每24秒生产一个中型阳光（25阳光值）", 
				this.getClass().getSimpleName(),this.getName(),
				this.getHitPiont(),
				this.getCriticalPiont(),
				this.getRecharge() / 1000.0,
				this.getCost(),
				this.getCooldownTime() / 1000.0,
				this.getPlaces());
	}
}
