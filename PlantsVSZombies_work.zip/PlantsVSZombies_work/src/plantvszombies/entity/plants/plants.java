package plantvszombies.entity.plants;

import plantvszombies.entity.AbstractSprite;

/**
 * 
 *
 * @植物总类
 * @作者 黄天佑
 * @时间 2017年10月27日下午5:56:37
 * @地点 教室
 *
 */
public abstract class plants extends AbstractSprite{

	/**
	 * 名称
	 */
	protected String name;

	/**
	 * 耐久：最大生命值
	 * 
	 * @简称 HP
	 */
	protected int hitPiont;

	/**
	 * 冷却时间：再次使用所需的准备时间
	 * 
	 * @简称 CD
	 */
	protected int cooldownTime;

	/**
	 * 价格：购买所需价格
	 */
	protected int Cost;

	/**
	 * 临界点：当植物生命值低于临界点时植物立刻消亡
	 * 
	 * @简称CRP
	 */
	protected int criticalPiont;

	/**
	 * 准备时间：植物安放后的生效准备时间
	 * 
	 * @简称 PT
	 * @单位 毫秒
	 */
	protected int prepareTime;

	/**
	 * 损失点1：当植物生命值低于其损伤点时出现破损效果
	 * 
	 * @计算公式 MAX HP*2/3
	 */
	protected int damagePiont1;

	/**
	 * 损失点2：当植物生命值低于其损伤点时出现破损效果
	 * 
	 * @计算公式 MAX HP*1/3
	 */
	protected int damagePiont2;

	/**
	 * 植物可种植位置
	 */
	protected String[] places;

	public plants() {
	}

	/**
	 * 根据指定的属性创建一个植物
	 * 
	 * @param name
	 *            植物的名称
	 * @param hitPiont
	 *            植物的最大耐久
	 * @param cooldownTime
	 *            植物使用冷却时间
	 * @param cost
	 *            植物购买价格
	 * @param criticalPiont
	 *            植物的耐久临界点
	 * @param prepareTime
	 *            植物的准备时间
	 * @param damagePiont1
	 *            植物的损伤点1
	 * @param damagePiont2
	 *            植物的损伤点2
	 * @param places
	 *            植物可栽种的地方
	 */
	public plants(String name, int hitPiont, int cooldownTime, int Cost, int criticalPiont, int prepareTime,
			int damagePiont1, int damagePiont2, String[] places) {
		this.name = name;
		this.hitPiont = hitPiont;
		this.cooldownTime = cooldownTime;
		this.Cost = Cost;
		this.criticalPiont = criticalPiont;
		this.prepareTime = prepareTime;
		this.damagePiont1 = damagePiont1;
		this.damagePiont2 = damagePiont2;
		this.places = places;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHitPiont() {
		return hitPiont;
	}

	public void setHitPiont(int hitPiont) {
		this.hitPiont = hitPiont;
	}

	public int getCooldownTime() {
		return cooldownTime;
	}

	public void setCooldownTime(int cooldownTime) {
		this.cooldownTime = cooldownTime;
	}

	public int getCost() {
		return Cost;
	}

	public void setCost(int Cost) {
		this.Cost = Cost;
	}

	public int getCriticalPiont() {
		return criticalPiont;
	}

	public void setCriticalPiont(int criticalPiont) {
		this.criticalPiont = criticalPiont;
	}

	public int getPrepareTime() {
		return prepareTime;
	}

	public void setPrepareTime(int prepareTime) {
		this.prepareTime = prepareTime;
	}

	public int getDamagePiont1() {
		return damagePiont1;
	}

	public void setDamagePiont1(int damagePiont1) {
		this.damagePiont1 = damagePiont1;
	}

	public int getDamagePiont2() {
		return damagePiont2;
	}

	public void setDamagePiont2(int damagePiont2) {
		this.damagePiont2 = damagePiont2;
	}

	public String[] getPlaces() {
		return places;
	}

	public void setPlaces(String[] places) {
		this.places = places;
	}

//	@Override
//	public String toString() {
//		return String.format(null, 0);
//	}
//	@SuppressWarnings("rawtypes")
//	class Goods implements Comparable{
//
//	@Override
//	public int compareTo(Object o) {
//		return 0;
//	}
//	}
//	@Override
//	public String toString() {
//		return "Goods [hitPiont="+hitPiont+",cooldownTime="+cooldownTime+",cost"+cost+",prepareTime"+prepareTime+"]";
//	
//	}
}
