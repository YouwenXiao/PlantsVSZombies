package plantvszombies.entity.plants;

/**
 * 
 * 项目名称:Plants vs.Zombies 
 * 类名称:AttackPlants
 *
 * 类描述:用来描述一个攻击类的植物
 *
 * @作者 黄天佑
 * @时间 2017年10月29日下午6:48:05
 * @地点 教室 @version-1.0.0
 */
public abstract class AttackPlants extends plants {
	/**
	 * 攻击力：攻击力(均以单发子弹计算)
	 * 
	 * @简称 ATK
	 */
	protected int attackPiont;

	/**
	 * 攻击射程/范围：攻击的有效距离/范围
	 */
	protected String range;

	/**
	 * 攻击间隔：每两次攻击之间的时间间隔
	 * 
	 * @单位 毫秒
	 */
	protected int recharge;

	public AttackPlants() {
		super();
	}

	/**
	 * 
	 * @param name
	 *            植物的名称
	 * @param hitPiont
	 *            植物的最大耐久
	 * @param cooldownTime
	 *            植物使用冷却时间
	 * @param cost
	 *            植物购买价格
	 * @param criticalPiont
	 *            植物的耐久临界点
	 * @param prepareTime
	 *            植物的准备时间
	 * @param damagePiont1
	 *            植物的损伤点1
	 * @param damagePiont2
	 *            植物的损伤点2
	 * @param places
	 *            植物可栽种的地方
	 * @param attackPiont
	 *            植物的攻击力
	 * @param range
	 *            植物的攻击射程/范围
	 * @param recharge
	 *            植物的攻击间隔时间
	 */
	public AttackPlants(String name, int hitPiont, int cooldownTime, int cost, int criticalPiont, int prepareTime,
			int damagePiont1, int damagePiont2, String[] places, int attackPiont, String range, int recharge) {
		super(name, hitPiont, cooldownTime, cost, criticalPiont, prepareTime, damagePiont1, damagePiont2, places);
		this.attackPiont = attackPiont;
		this.range = range;
		this.recharge = recharge;
	}

	public int getAttackPiont() {
		return attackPiont;
	}

	public void setAttackPiont(int attackPiont) {
		this.attackPiont = attackPiont;
	}

	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}

	public int getRecharge() {
		return recharge;
	}

	public void setRecharge(int recharge) {
		this.recharge = recharge;
	}

	/**
	 * 植物的攻击
	 */
	public abstract void attack();

//	@Override
//	public String toString() {
//		return String.format("\n%s%s\r\n"+
//                "耐久:%s\r\n"+
//                "临界点:%s\r\n"+
//                "攻击:%s\r\n"+
//                "射程:%s\r\n"+
//                "射击间隔:%s秒\r\n"+
//                "价格: %s阳光\r\n"+
//                "冷却时间:%s秒\r\n"+
//                "可栽种于可栽种于草地/睡莲/花盆",                            
//                this.getClass().getSimpleName(),
//                this.getName(),
//                this.getHitPiont(),
//                this.getCriticalPiont(),
//                this.getAttackPiont(),
//                this.getRange(),
//                this.getRecharge()/1000.0,
//                this.getCost(),
//                this.getCooldownTime()/1000.0,
//                this.getPlaces());
//	}
	
}
