package plantvszombies.entity.plants;

public abstract class AssistPlants extends plants {
	/**
	 * 生产间隔
	 * 
	 * @单位 毫秒
	 */
	protected int recharge;
	
	public AssistPlants() {
		super();
	}
	
	/**
	 * 
	 * @param name
	 *            植物的名称
	 * @param hitPiont
	 *            植物的最大耐久
	 * @param cooldownTime
	 *            植物使用冷却时间
	 * @param cost
	 *            植物购买价格
	 * @param criticalPiont
	 *            植物的耐久临界点
	 * @param prepareTime
	 *            植物的准备时间
	 * @param damagePiont1
	 *            植物的损伤点1
	 * @param damagePiont2
	 *            植物的损伤点2
	 * @param places
	 *            植物可栽种的地方
	 * @param recharge
	 *            植物的生产间隔时间
	 */
	public AssistPlants(String name, int hitPiont, int cooldownTime, int cost, int criticalPiont, int prepareTime,
			int damagePiont1, int damagePiont2, String[] places, int recharge) {
		super(name, hitPiont, cooldownTime, cost, criticalPiont, prepareTime, damagePiont1, damagePiont2, places);
		this.recharge = recharge;
	}
	
	public int getRecharge() {
		return recharge;
	}

	public void setRecharge(int recharge) {
		this.recharge = recharge;
	}
	
	/**
	 * 植物的生产
	 */
	public abstract void production();
}
