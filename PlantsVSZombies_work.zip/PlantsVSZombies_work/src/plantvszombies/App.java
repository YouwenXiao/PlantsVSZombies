package plantvszombies;
import javax.swing.SwingUtilities;

import plantvszombies.ui.MainFrame;

/**
 * 
 * @项目名称:PlantVSZombiesCode
 * @类名称:App
 *
 * 			类描述:
 *
 * @作者 黄天佑
 * @时间 2017年11月21日下午5:13:29
 * @地点 教室 @version-1.0.0
 */
public class App {
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				new MainFrame().setVisible(true);
			}
		});
	}
}
