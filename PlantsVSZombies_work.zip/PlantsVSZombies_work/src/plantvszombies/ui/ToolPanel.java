package plantvszombies.ui;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class ToolPanel extends JPanel{

	private Image backgroundImage = Toolkit.getDefaultToolkit().createImage("images/interface/top.gif");
	public ToolPanel(){
		setSize(599, 87);
		setOpaque(false);
		//设置布局的方式为浮动布局（从左往右）
		setLayout(new FlowLayout(FlowLayout.LEFT,2,0));
		setBorder(new EmptyBorder(8, 72, 5, 5));
		//添加卡片
		Image peashooter = Toolkit.getDefaultToolkit().createImage("images/Card/Plants/Peashooter.png");
		Image sunFlower = Toolkit.getDefaultToolkit().createImage("images/Card/Plants/SunFlower.png");
		Image snowPea = Toolkit.getDefaultToolkit().createImage("images/Card/Plants/SnowPea.png");
		add(new Card(peashooter,"Peashooter"));
		add(new Card(sunFlower,"SunFlower"));
		add(new Card(snowPea, "SnowPea"));
		}
	@Override
	protected void paintChildren(Graphics g) {
		//绘制工具面板的背景图
		g.drawImage(backgroundImage, 0, 0, this);
		super.paintChildren(g);
	}
	/**
	 * 得到工具面板中选中的卡片
	 * @return
	 */
	public Card getSelectedCard(){
		Component[] components =getComponents();
		for (Component component : components) {
			if (component instanceof Card) {
				Card other = (Card)component;
				if(other.isSelected()){
					return other;
				}
			}
		}
		
		return null;
	}
	
}
