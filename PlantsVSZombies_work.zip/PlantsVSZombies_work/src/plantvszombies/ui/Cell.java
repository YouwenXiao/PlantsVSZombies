package plantvszombies.ui;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;

import plantvszombies.entity.AbstractSprite;
import plantvszombies.entity.plants.plants;

public class Cell extends Rectangle {

	private boolean putable = true;
	
	private AbstractSprite sprite;
	
	public boolean isPutable() {
		return putable;
	}

	public void setPutable(boolean putable) {
		this.putable = putable;
	}

	public Cell() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cell(Dimension d) {
		super(d);
		// TODO Auto-generated constructor stub
	}

	public Cell(int x, int y, int width, int height) {
		super(x, y, width, height);
		// TODO Auto-generated constructor stub
	}

	public Cell(int width, int height) {
		super(width, height);
		// TODO Auto-generated constructor stub
	}

	public Cell(Point p, Dimension d) {
		super(p, d);
		// TODO Auto-generated constructor stub
	}

	public Cell(Point p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

	public Cell(Rectangle r) {
		super(r);
		// TODO Auto-generated constructor stub
	}
	
	
	public boolean canPutPlants() {
		if (sprite == null) {
			return true;
		}
		if (sprite instanceof plants) {
			return false;
		}
		return true;
	}
}
