package plantvszombies.ui;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import plantvszombies.entity.plants.plants;
import plantvszombies.entity.plants.assistplants.SunFlower;
import plantvszombies.entity.plants.attackplants.Peashooter;
import plantvszombies.entity.plants.attackplants.SnowPea;


public class ContentPane extends JPanel{


	private ToolPanel toolPanel = new ToolPanel();
	
	ArrayList<plants>plants = new ArrayList<>();
	
	//map
	private Image backgroundImage = Toolkit.getDefaultToolkit().createImage("images/interface/background1.jpg");
	
	//记录地图路劲数据（可摆放地图位置）
	ArrayList<Cell> rectangles = new ArrayList<>();
	
	
	
	public ContentPane() {
		super();
		//设置内容面板的布局方式为绝对布局
		setLayout(null);
		add(toolPanel);
		
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//判断鼠标是否点在可以摆放植物的位置
//				boolean cellSelected = false;
				Cell selectedCell = null;
				for (Cell r : rectangles) {
					if(r.contains(e.getPoint())) {
//						cellSelected = true;
						selectedCell = r;
						break;
					}
				}
//				if(!cellSelected) {
//					return;
//				}
				if(selectedCell == null || !selectedCell.isPutable()) {
					return;
				}
				
				Card selectedCard = toolPanel.getSelectedCard();
				if (selectedCard == null) {
					return;
				}
				selectedCard.startAnimation();
				
				switch (selectedCard.getName()) {
				case "Peashooter":
					Peashooter peashooter = new Peashooter();
//					peashooter.setX(e.getX());
//					peashooter.setY(e.getY());
					peashooter.setImage(Toolkit.getDefaultToolkit().createImage("images/Plants/Peashooter/Peashooter.gif"));
					peashooter.setX(selectedCell.x + (selectedCell.width - new ImageIcon(peashooter.getImage()).getIconWidth()) / 2);
					peashooter.setY(selectedCell.y + (selectedCell.height - new ImageIcon(peashooter.getImage()).getIconHeight()) / 2);
					selectedCell.setPutable(false);
					plants.add(peashooter);
					break;
					
				case "SunFlower":
					SunFlower sunFlower = new SunFlower();
//					sunFlower.setX(e.getX());
//					sunFlower.setY(e.getY());
					sunFlower.setImage(Toolkit.getDefaultToolkit().createImage("images/Plants/SunFlower/SunFlower.gif"));
					sunFlower.setX(selectedCell.x + (selectedCell.width - new ImageIcon(sunFlower.getImage()).getIconWidth()) / 2);
					sunFlower.setY(selectedCell.y + (selectedCell.height - new ImageIcon(sunFlower.getImage()).getIconHeight()) / 2);
					selectedCell.setPutable(false);
					plants.add(sunFlower);
					break;
					
				case "SnowPea":
					SnowPea snowPea = new SnowPea();
//					snowPea.setX(e.getX());
//					snowPea.setY(e.getY());
					snowPea.setImage(Toolkit.getDefaultToolkit().createImage("images/Plants/SnowPea/SnowPea.gif"));
					snowPea.setX(selectedCell.x + (selectedCell.width - new ImageIcon(snowPea.getImage()).getIconWidth()) / 2);
					snowPea.setY(selectedCell.y + (selectedCell.height - new ImageIcon(snowPea.getImage()).getIconHeight()) / 2);
					selectedCell.setPutable(false);
					plants.add(snowPea);
					break;

				default:
					break;
				}
				
				
//				Component[] components =toolPanel.getComponents();
//				for (Component component : components) {
//					if(component instanceof Card){
//						Card card = (Card)component;
//						if(card.isSelected()){
//							selectedCard = card;
//							break;
//						}
//					}
//				}
			}
		});
		
		//构造地图数据
		
		//第一排
		rectangles.add(new Cell(79, 88, 83, 95));
		rectangles.add(new Cell(163, 86, 80, 93));
		rectangles.add(new Cell(244, 88, 76, 96));
		rectangles.add(new Cell(321, 88, 83, 96));
		rectangles.add(new Cell(405, 88, 80, 93));
		rectangles.add(new Cell(486, 82, 82, 98));
		rectangles.add(new Cell(569, 90, 75, 93));
		rectangles.add(new Cell(645, 89, 76, 93));
		rectangles.add(new Cell(722, 90, 92, 93));
		
		//第二排
		rectangles.add(new Cell(79, 183, 83, 93));
		rectangles.add(new Cell(163, 179, 80, 93));
		rectangles.add(new Cell(244, 184, 76, 93));
		rectangles.add(new Cell(321, 184, 83, 93));
		rectangles.add(new Cell(405, 181, 80, 93));
		rectangles.add(new Cell(486, 180, 82, 98));
		rectangles.add(new Cell(569, 183, 75, 93));
		rectangles.add(new Cell(645, 182, 76, 93));
		rectangles.add(new Cell(722, 183, 92, 93));
	
		//第三排
		rectangles.add(new Cell(79, 276, 83, 102));
		rectangles.add(new Cell(163, 272, 80, 105));
		rectangles.add(new Cell(244, 277, 76, 98));
		rectangles.add(new Cell(321, 277, 83, 104));
		rectangles.add(new Cell(405, 274, 80, 109));
		rectangles.add(new Cell(486, 278, 82, 105));
		rectangles.add(new Cell(569, 276, 75, 106));
		rectangles.add(new Cell(645, 275, 76, 107));
		rectangles.add(new Cell(722, 276, 92, 106));
		
		//第四排
		rectangles.add(new Cell(79, 378, 83, 93));
		rectangles.add(new Cell(163, 377, 80, 93));
		rectangles.add(new Cell(244, 375, 76, 93));
		rectangles.add(new Cell(321, 381, 83, 93));
		rectangles.add(new Cell(405, 383, 80, 93));
		rectangles.add(new Cell(486, 383, 82, 93));
		rectangles.add(new Cell(569, 382, 75, 93));
		rectangles.add(new Cell(645, 382, 76, 93));
		rectangles.add(new Cell(722, 382, 92, 93));
		
		//第五排
		rectangles.add(new Cell(79, 471, 83, 98));
		rectangles.add(new Cell(163, 470, 80, 101));
		rectangles.add(new Cell(244, 468, 76, 105));
		rectangles.add(new Cell(321, 474, 83, 95));
		rectangles.add(new Cell(405, 476, 80, 93));
		rectangles.add(new Cell(486, 476, 82, 93));
		rectangles.add(new Cell(569, 475, 75, 96));
		rectangles.add(new Cell(645, 475, 76, 98));
		rectangles.add(new Cell(722, 475, 92, 100));
	}


	@Override
	protected void paintChildren(Graphics g) {
		//绘制场景
		g.drawImage(backgroundImage, -170, 0, this);
//		System.out.println(backgroundImage.getWidth(this));
		
		//绘制网络
		for (Rectangle r : rectangles) {
			g.drawRect(r.x, r.y, r.width, r.height);
		}
		
		//绘制精灵
		for (plants p : plants) {
			p.draw(g, this);
		}
		super.paintChildren(g);
	}

	
}
