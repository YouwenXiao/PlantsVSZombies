package plantvszombies.ui;

import java.awt.Color;
import java.awt.Rectangle;

import javax.swing.JFrame;

import com.sun.xml.internal.bind.v2.runtime.reflect.Accessor.SetterOnlyReflection;

public class MainFrame extends JFrame implements Runnable{

	private ContentPane contentPane= new ContentPane();
	
	
	public MainFrame(){
		setTitle("植物大战僵尸");
		//默认关闭
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		//设置大小
		setSize(1000, 629);
		//
		setLocationRelativeTo(null);
		//设置不可改变大小
		setResizable(false);
		
		//植物框
		setContentPane(contentPane);
//		contentPane.add(toolPanel);
		//背景色
		contentPane.setBackground(Color.RED);
		
		
		//启动绘制
		new Thread(this).start();
	}


	@Override
	public void run() {
		//控制整个游戏的绘制
		while(true){
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			this.repaint();
		}
	}
}
