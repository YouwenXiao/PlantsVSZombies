package plantvszombies.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class Card extends JPanel implements Runnable {

	private Image image;

	private int maskHeight;

	private int cooldownTime = 7500;

	private boolean selected = false;

	private boolean canUse = true;

	private String name ;
	
	public Card(Image image,String name) {
		this.image = image;
		this.name = name ;
		// 设置宽高
		setPreferredSize(new Dimension(50, 70));
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// 判断其他的卡片是否有选中的
				// 1.得到其他的卡片
				// Component[] components =
				// Card.this.getParent().getComponents();
				// for (Component component : components) {
				// if (component instanceof Card) {
				// Card other = (Card)component;
				// if(other.isSelected()){
				// other.setSelected(false);
				// }
				// }
				// }
				ToolPanel toolPanel = (ToolPanel) Card.this.getParent();
				Card selectedCard = toolPanel.getSelectedCard();
				if (selectedCard != null) {
					selectedCard.setSelected(false);
				}
				// 判断当前的卡片是否可用
				if (canUse) {
					Card.this.setSelected(true);
				}
				// maskHeight = Card.this.getHeight();
				// 启动动画
				// new Thread(Card.this).start();
				// 重新绘制卡片
				Card.this.repaint();
			}
		});
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(image, 0, 0, this);
		// System.out.println("绘制遮罩层"+getWidth());
		// 设置绘制的颜色
		g.setColor(new Color(0, 0, 0, 100));
		g.fillRect(0, 0, getWidth(), maskHeight);
	}

	@Override
	public void run() {

		// 冷却动画效果 70 7500
		while (maskHeight > 0) {
			try {
				Thread.sleep(cooldownTime / getHeight());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			maskHeight--;
			this.repaint();

		}
		maskHeight = 0;
		canUse = true;
	}

	public void startAnimation() {
		canUse = false;
		new Thread(this).start();
		selected = false;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
		if (selected) {
			maskHeight = getHeight();
		} else {
			maskHeight = 0;
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
